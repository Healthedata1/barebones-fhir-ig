package http://www.fhir.org/guides/test40/ImplementationGuide/ig;

import org.hl7.fhir.r4.model.ProfilingWrapper;

public class Templatebasic {

}
